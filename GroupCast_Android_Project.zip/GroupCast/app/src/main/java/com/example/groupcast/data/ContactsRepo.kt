package com.example.groupcast.data

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Phone

object ContactsRepo {
    /** Reads device contacts that have a phone number; one entry per distinct number. */
    fun load(ctx: Context): List<Contact> {
        val out = LinkedHashMap<String, Contact>()
        val projection = arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER)
        ctx.contentResolver.query(Phone.CONTENT_URI, projection, null, null, null)?.use { c ->
            val nameIdx = c.getColumnIndexOrThrow(Phone.DISPLAY_NAME)
            val numIdx = c.getColumnIndexOrThrow(Phone.NUMBER)
            while (c.moveToNext()) {
                val number = c.getString(numIdx)?.trim().orEmpty()
                val name = c.getString(nameIdx)?.trim().orEmpty().ifEmpty { number }
                val contact = Contact(name, number)
                if (contact.key.isNotEmpty() && !out.containsKey(contact.key)) out[contact.key] = contact
            }
        }
        return out.values.sortedBy { it.name.lowercase() }
    }
}
