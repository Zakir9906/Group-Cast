package com.example.groupcast.data

import android.content.Context
import android.content.SharedPreferences

object Session {
    private fun prefs(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("session", Context.MODE_PRIVATE)

    fun save(ctx: Context, u: User) {
        prefs(ctx).edit()
            .putLong("id", u.id)
            .putString("username", u.username)
            .putString("phone", u.phone)
            .putString("role", u.role)
            .apply()
    }

    fun current(ctx: Context): User? {
        val p = prefs(ctx)
        val id = p.getLong("id", -1L)
        val role = p.getString("role", null) ?: return null
        if (id < 0) return null
        return User(id, p.getString("username", "").orEmpty(), p.getString("phone", "").orEmpty(), role)
    }

    fun clear(ctx: Context) {
        prefs(ctx).edit().clear().apply()
    }
}
