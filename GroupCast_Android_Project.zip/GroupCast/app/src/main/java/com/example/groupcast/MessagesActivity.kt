package com.example.groupcast

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.groupcast.data.Db
import com.example.groupcast.data.ROLE_ADMIN
import com.example.groupcast.data.Session
import com.example.groupcast.data.phoneKey
import com.example.groupcast.databinding.ActivityMessagesBinding

/** Admin: read + post. Regular user: read only (composer is hidden and posting is never reachable). */
class MessagesActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_GROUP_ID = "group_id"
        const val EXTRA_GROUP_NAME = "group_name"
    }

    private lateinit var b: ActivityMessagesBinding
    private lateinit var db: Db
    private val adapter = MessageAdapter()
    private var groupId = -1L
    private var isAdmin = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val user = Session.current(this)
        groupId = intent.getLongExtra(EXTRA_GROUP_ID, -1L)
        if (user == null || groupId < 0) {
            finish()
            return
        }
        db = Db.get(this)
        isAdmin = user.role == ROLE_ADMIN
        if (!isAdmin && !db.isMember(groupId, phoneKey(user.phone))) {
            finish()
            return
        }

        b = ActivityMessagesBinding.inflate(layoutInflater)
        setContentView(b.root)
        supportActionBar?.apply {
            title = intent.getStringExtra(EXTRA_GROUP_NAME).orEmpty()
            setDisplayHomeAsUpEnabled(true)
        }

        b.recycler.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        b.recycler.adapter = adapter

        b.composer.visibility = if (isAdmin) View.VISIBLE else View.GONE
        b.tvReadOnly.visibility = if (isAdmin) View.GONE else View.VISIBLE
        if (isAdmin) b.btnSend.setOnClickListener { send() }

        reload()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun reload() {
        val list = db.messages(groupId)
        adapter.submit(list)
        b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        b.tvEmpty.text = if (isAdmin) "No messages yet. Write the first one below."
        else "No messages yet. Check back later."
        if (list.isNotEmpty()) b.recycler.scrollToPosition(list.size - 1)
    }

    private fun send() {
        if (!isAdmin) return
        val text = b.etMessage.text?.toString().orEmpty().trim()
        if (text.isEmpty()) return
        db.postMessage(groupId, text)
        b.etMessage.text?.clear()
        reload()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        if (!isAdmin) return false
        menuInflater.inflate(R.menu.menu_group, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_members) {
            val members = db.members(groupId)
            AlertDialog.Builder(this)
                .setTitle("Members (${members.size})")
                .setItems(members.map { "${it.name}\n${it.phone}" }.toTypedArray(), null)
                .setPositiveButton("Close", null)
                .show()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
