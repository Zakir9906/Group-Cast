package com.example.groupcast

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.groupcast.data.ContactsRepo
import com.example.groupcast.data.Db
import com.example.groupcast.data.ROLE_ADMIN
import com.example.groupcast.data.Session
import com.example.groupcast.databinding.ActivityCreateGroupBinding

/** Admin-only screen: pick contacts from the phone and save them as a group. */
class CreateGroupActivity : AppCompatActivity() {

    private lateinit var b: ActivityCreateGroupBinding
    private var adapter: ContactAdapter? = null
    private var loading = false
    private var askedOnce = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadContacts()
            else showStatus("Contacts permission is needed to choose group members.", true)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val user = Session.current(this)
        if (user == null || user.role != ROLE_ADMIN) {
            finish()
            return
        }
        b = ActivityCreateGroupBinding.inflate(layoutInflater)
        setContentView(b.root)
        supportActionBar?.apply {
            title = "New group"
            setDisplayHomeAsUpEnabled(true)
        }

        b.etSearch.doAfterTextChanged { adapter?.filter(it?.toString().orEmpty()) }
        b.btnGrant.setOnClickListener { requestAccess() }
        b.btnCreate.setOnClickListener { createGroup() }

        if (hasPermission()) loadContacts() else requestAccess()
    }

    override fun onResume() {
        super.onResume()
        // Covers the case where the user granted access from system settings.
        if (::b.isInitialized && adapter == null && !loading && hasPermission()) loadContacts()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun hasPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (askedOnce && !shouldShowRequestPermissionRationale(Manifest.permission.READ_CONTACTS)) {
            // Permission was permanently denied: send the user to app settings.
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
            )
        } else {
            askedOnce = true
            permissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    private fun showStatus(message: String, showButton: Boolean) {
        b.progress.visibility = View.GONE
        b.recycler.visibility = View.GONE
        b.statusBox.visibility = View.VISIBLE
        b.tvStatus.text = message
        b.btnGrant.visibility = if (showButton) View.VISIBLE else View.GONE
    }

    private fun loadContacts() {
        if (loading || adapter != null) return
        loading = true
        b.statusBox.visibility = View.GONE
        b.progress.visibility = View.VISIBLE
        val appContext = applicationContext
        Thread {
            val list = try {
                ContactsRepo.load(appContext)
            } catch (e: Exception) {
                emptyList()
            }
            runOnUiThread {
                loading = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                b.progress.visibility = View.GONE
                if (list.isEmpty()) {
                    showStatus("No contacts with phone numbers were found on this device.", false)
                    return@runOnUiThread
                }
                adapter = ContactAdapter(list) { count -> b.tvSelected.text = "$count selected" }
                b.recycler.layoutManager = LinearLayoutManager(this)
                b.recycler.adapter = adapter
                b.recycler.visibility = View.VISIBLE
            }
        }.start()
    }

    private fun createGroup() {
        val name = b.etGroupName.text?.toString().orEmpty().trim()
        if (name.isEmpty()) {
            b.tilGroupName.error = "Enter a group name"
            return
        }
        b.tilGroupName.error = null
        val picked = adapter?.selectedContacts().orEmpty()
        if (picked.isEmpty()) {
            Toast.makeText(this, "Select at least one contact", Toast.LENGTH_SHORT).show()
            return
        }
        Db.get(this).createGroup(name, picked)
        Toast.makeText(this, "Group \"$name\" created with ${picked.size} members", Toast.LENGTH_LONG).show()
        finish()
    }
}
