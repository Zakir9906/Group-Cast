package com.example.groupcast

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.groupcast.data.Db
import com.example.groupcast.data.ROLE_ADMIN
import com.example.groupcast.data.ROLE_USER
import com.example.groupcast.data.Session
import com.example.groupcast.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var b: ActivityLoginBinding

    private val selectedRole: String
        get() = if (b.roleToggle.checkedButtonId == R.id.btnRoleAdmin) ROLE_ADMIN else ROLE_USER

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.current(this) != null) {
            openHome()
            return
        }
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)
        supportActionBar?.hide()

        b.roleToggle.check(R.id.btnRoleUser)
        refreshRoleUi()
        b.roleToggle.addOnButtonCheckedListener { _, _, isChecked ->
            if (isChecked) refreshRoleUi()
        }

        b.btnLogin.setOnClickListener { attemptLogin() }
        b.btnRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun refreshRoleUi() {
        val admin = selectedRole == ROLE_ADMIN
        b.btnRegister.visibility = if (admin) View.GONE else View.VISIBLE
        b.tvHint.text = if (admin) {
            "Default admin account: username admin, password admin123"
        } else {
            "Register with the phone number the admin has in their contacts to see your groups."
        }
    }

    private fun attemptLogin() {
        val username = b.etUsername.text?.toString().orEmpty().trim()
        val password = b.etPassword.text?.toString().orEmpty()
        b.tilUsername.error = if (username.isEmpty()) "Enter your username" else null
        b.tilPassword.error = if (password.isEmpty()) "Enter your password" else null
        if (username.isEmpty() || password.isEmpty()) return

        val user = Db.get(this).login(username, password, selectedRole)
        if (user == null) {
            Toast.makeText(this, "Wrong username or password for this login type", Toast.LENGTH_LONG).show()
            return
        }
        Session.save(this, user)
        openHome()
    }

    private fun openHome() {
        startActivity(Intent(this, GroupListActivity::class.java))
        finish()
    }
}
