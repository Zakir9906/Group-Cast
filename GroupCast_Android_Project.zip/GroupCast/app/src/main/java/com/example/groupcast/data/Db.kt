package com.example.groupcast.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest
import java.security.SecureRandom

const val ROLE_ADMIN = "admin"
const val ROLE_USER = "user"

data class User(val id: Long, val username: String, val phone: String, val role: String)
data class Contact(val name: String, val phone: String) {
    val key: String get() = phoneKey(phone)
}
data class Group(val id: Long, val name: String, val memberCount: Int, val messageCount: Int)
data class Message(val id: Long, val body: String, val createdAt: Long)

/** Normalises a phone number so "+1 (555) 123-4567" and "5551234567" match. */
fun phoneKey(raw: String): String {
    val digits = raw.filter { it.isDigit() }
    return if (digits.length > 10) digits.takeLast(10) else digits
}

class Db private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "groupcast.db", null, 1) {

    companion object {
        @Volatile private var instance: Db? = null

        fun get(ctx: Context): Db =
            instance ?: synchronized(this) {
                instance ?: Db(ctx.applicationContext).also { instance = it }
            }

        private fun newSalt(): String {
            val bytes = ByteArray(16)
            SecureRandom().nextBytes(bytes)
            return bytes.joinToString("") { "%02x".format(it) }
        }

        private fun hash(salt: String, password: String): String =
            MessageDigest.getInstance("SHA-256")
                .digest((salt + password).toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }

        private fun insertUser(
            db: SQLiteDatabase, username: String, phone: String, password: String, role: String
        ): Long {
            val salt = newSalt()
            val cv = ContentValues().apply {
                put("username", username)
                put("phone", phoneKey(phone))
                put("salt", salt)
                put("hash", hash(salt, password))
                put("role", role)
            }
            return db.insert("users", null, cv)
        }
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                "phone TEXT NOT NULL DEFAULT '', " +
                "salt TEXT NOT NULL, hash TEXT NOT NULL, role TEXT NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE groups (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, created_at INTEGER NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE members (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE, " +
                "name TEXT NOT NULL, phone TEXT NOT NULL, phone_key TEXT NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_members_group ON members(group_id)")
        db.execSQL("CREATE INDEX idx_members_key ON members(phone_key)")
        db.execSQL(
            "CREATE TABLE messages (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE, " +
                "body TEXT NOT NULL, created_at INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_messages_group ON messages(group_id)")

        // Default administrator account (change the password for real use).
        insertUser(db, "admin", "", "admin123", ROLE_ADMIN)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Version 1 only.
    }

    // ---------- Accounts ----------

    fun login(username: String, password: String, role: String): User? {
        readableDatabase.rawQuery(
            "SELECT id, username, phone, salt, hash, role FROM users WHERE username = ? AND role = ?",
            arrayOf(username.trim(), role)
        ).use { c ->
            if (!c.moveToFirst()) return null
            return if (hash(c.getString(3), password) == c.getString(4)) {
                User(c.getLong(0), c.getString(1), c.getString(2), c.getString(5))
            } else null
        }
    }

    /** Returns false if the username is already taken. Only regular users can self-register. */
    fun registerUser(username: String, phone: String, password: String): Boolean =
        try {
            insertUser(writableDatabase, username.trim(), phone, password, ROLE_USER) != -1L
        } catch (e: Exception) {
            false
        }

    // ---------- Groups ----------

    fun createGroup(name: String, contacts: List<Contact>): Long {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val gid = db.insert("groups", null, ContentValues().apply {
                put("name", name.trim())
                put("created_at", System.currentTimeMillis())
            })
            for (c in contacts) {
                db.insert("members", null, ContentValues().apply {
                    put("group_id", gid)
                    put("name", c.name)
                    put("phone", c.phone)
                    put("phone_key", c.key)
                })
            }
            db.setTransactionSuccessful()
            return gid
        } finally {
            db.endTransaction()
        }
    }

    /** All groups (admin), or only groups containing [forPhoneKey] (regular user). */
    fun groups(forPhoneKey: String? = null): List<Group> {
        if (forPhoneKey != null && forPhoneKey.isEmpty()) return emptyList()
        val sql = StringBuilder(
            "SELECT g.id, g.name, " +
                "(SELECT COUNT(*) FROM members m WHERE m.group_id = g.id), " +
                "(SELECT COUNT(*) FROM messages x WHERE x.group_id = g.id) FROM groups g"
        )
        val args = ArrayList<String>()
        if (forPhoneKey != null) {
            sql.append(" WHERE g.id IN (SELECT group_id FROM members WHERE phone_key = ?)")
            args.add(forPhoneKey)
        }
        sql.append(" ORDER BY g.created_at DESC")
        val out = ArrayList<Group>()
        readableDatabase.rawQuery(sql.toString(), args.toTypedArray()).use { c ->
            while (c.moveToNext()) out.add(Group(c.getLong(0), c.getString(1), c.getInt(2), c.getInt(3)))
        }
        return out
    }

    fun deleteGroup(groupId: Long) {
        writableDatabase.delete("groups", "id = ?", arrayOf(groupId.toString()))
    }

    fun members(groupId: Long): List<Contact> {
        val out = ArrayList<Contact>()
        readableDatabase.rawQuery(
            "SELECT name, phone FROM members WHERE group_id = ? ORDER BY name COLLATE NOCASE",
            arrayOf(groupId.toString())
        ).use { c -> while (c.moveToNext()) out.add(Contact(c.getString(0), c.getString(1))) }
        return out
    }

    fun isMember(groupId: Long, phoneKey: String): Boolean {
        if (phoneKey.isEmpty()) return false
        readableDatabase.rawQuery(
            "SELECT 1 FROM members WHERE group_id = ? AND phone_key = ? LIMIT 1",
            arrayOf(groupId.toString(), phoneKey)
        ).use { return it.moveToFirst() }
    }

    // ---------- Messages ----------

    fun postMessage(groupId: Long, body: String) {
        writableDatabase.insert("messages", null, ContentValues().apply {
            put("group_id", groupId)
            put("body", body.trim())
            put("created_at", System.currentTimeMillis())
        })
    }

    fun messages(groupId: Long): List<Message> {
        val out = ArrayList<Message>()
        readableDatabase.rawQuery(
            "SELECT id, body, created_at FROM messages WHERE group_id = ? ORDER BY created_at ASC, id ASC",
            arrayOf(groupId.toString())
        ).use { c -> while (c.moveToNext()) out.add(Message(c.getLong(0), c.getString(1), c.getLong(2))) }
        return out
    }
}
