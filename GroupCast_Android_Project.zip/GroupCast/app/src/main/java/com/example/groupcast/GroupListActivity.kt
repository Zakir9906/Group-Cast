package com.example.groupcast

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.groupcast.data.Db
import com.example.groupcast.data.ROLE_ADMIN
import com.example.groupcast.data.Session
import com.example.groupcast.data.User
import com.example.groupcast.data.phoneKey
import com.example.groupcast.databinding.ActivityGroupListBinding

class GroupListActivity : AppCompatActivity() {

    private lateinit var b: ActivityGroupListBinding
    private lateinit var user: User
    private lateinit var adapter: GroupAdapter

    private val isAdmin get() = user.role == ROLE_ADMIN

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val current = Session.current(this)
        if (current == null) {
            goToLogin()
            return
        }
        user = current
        b = ActivityGroupListBinding.inflate(layoutInflater)
        setContentView(b.root)

        supportActionBar?.apply {
            title = if (isAdmin) "Admin: groups" else "My groups"
            subtitle = "Signed in as ${user.username}"
        }

        adapter = GroupAdapter(
            onClick = { g ->
                startActivity(
                    Intent(this, MessagesActivity::class.java)
                        .putExtra(MessagesActivity.EXTRA_GROUP_ID, g.id)
                        .putExtra(MessagesActivity.EXTRA_GROUP_NAME, g.name)
                )
            },
            onLongClick = { g -> if (isAdmin) confirmDelete(g.id, g.name) }
        )
        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter

        b.fab.visibility = if (isAdmin) View.VISIBLE else View.GONE
        b.fab.setOnClickListener { startActivity(Intent(this, CreateGroupActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        if (::user.isInitialized) reload()
    }

    private fun reload() {
        val db = Db.get(this)
        val list = if (isAdmin) db.groups() else db.groups(phoneKey(user.phone))
        adapter.submit(list)
        b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        b.tvEmpty.text = if (isAdmin) {
            "No groups yet.\nTap + to create one from your contacts."
        } else {
            "You are not in any group yet.\nThe admin adds you using the phone number you registered with."
        }
    }

    private fun confirmDelete(id: Long, name: String) {
        AlertDialog.Builder(this)
            .setTitle("Delete group?")
            .setMessage("\"$name\" and all of its messages will be removed.")
            .setPositiveButton("Delete") { _, _ ->
                Db.get(this).deleteGroup(id)
                reload()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_logout) {
            Session.clear(this)
            goToLogin()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun goToLogin() {
        startActivity(
            Intent(this, LoginActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        finish()
    }
}
