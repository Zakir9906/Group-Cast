package com.example.groupcast

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.groupcast.data.Db
import com.example.groupcast.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {

    private lateinit var b: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(b.root)
        supportActionBar?.apply {
            title = "Create user account"
            setDisplayHomeAsUpEnabled(true)
        }
        b.btnRegister.setOnClickListener { register() }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun register() {
        val username = b.etUsername.text?.toString().orEmpty().trim()
        val phone = b.etPhone.text?.toString().orEmpty().trim()
        val password = b.etPassword.text?.toString().orEmpty()
        val confirm = b.etConfirm.text?.toString().orEmpty()

        b.tilUsername.error = if (username.length < 3) "At least 3 characters" else null
        b.tilPhone.error = if (phone.count { it.isDigit() } < 7) "Enter a valid phone number" else null
        b.tilPassword.error = if (password.length < 6) "At least 6 characters" else null
        b.tilConfirm.error = if (confirm != password) "Passwords do not match" else null
        if (listOf(b.tilUsername, b.tilPhone, b.tilPassword, b.tilConfirm).any { it.error != null }) return

        if (Db.get(this).registerUser(username, phone, password)) {
            Toast.makeText(this, "Account created. Please log in.", Toast.LENGTH_LONG).show()
            finish()
        } else {
            b.tilUsername.error = "That username is already taken"
        }
    }
}
