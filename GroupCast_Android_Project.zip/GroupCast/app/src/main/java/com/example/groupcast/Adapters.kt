package com.example.groupcast

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.groupcast.data.Contact
import com.example.groupcast.data.Group
import com.example.groupcast.data.Message
import com.example.groupcast.databinding.ItemContactBinding
import com.example.groupcast.databinding.ItemGroupBinding
import com.example.groupcast.databinding.ItemMessageBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GroupAdapter(
    private val onClick: (Group) -> Unit,
    private val onLongClick: (Group) -> Unit
) : RecyclerView.Adapter<GroupAdapter.VH>() {

    class VH(val b: ItemGroupBinding) : RecyclerView.ViewHolder(b.root)

    private var items: List<Group> = emptyList()

    fun submit(list: List<Group>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemGroupBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val g = items[position]
        holder.b.tvName.text = g.name
        holder.b.tvMeta.text = "${g.memberCount} members  |  ${g.messageCount} messages"
        holder.b.root.setOnClickListener { onClick(g) }
        holder.b.root.setOnLongClickListener { onLongClick(g); true }
    }
}

class ContactAdapter(
    val all: List<Contact>,
    private val onChange: (Int) -> Unit
) : RecyclerView.Adapter<ContactAdapter.VH>() {

    class VH(val b: ItemContactBinding) : RecyclerView.ViewHolder(b.root)

    private var shown: List<Contact> = all
    private val selected = LinkedHashSet<String>()

    fun filter(query: String) {
        val q = query.trim().lowercase()
        shown = if (q.isEmpty()) all
        else all.filter { it.name.lowercase().contains(q) || it.phone.contains(q) }
        notifyDataSetChanged()
    }

    fun selectedContacts(): List<Contact> = all.filter { it.key in selected }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemContactBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = shown.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = shown[position]
        holder.b.tvName.text = c.name
        holder.b.tvPhone.text = c.phone
        holder.b.checkbox.isChecked = c.key in selected
        holder.b.root.setOnClickListener {
            val nowSelected = selected.add(c.key)
            if (!nowSelected) selected.remove(c.key)
            holder.b.checkbox.isChecked = nowSelected
            onChange(selected.size)
        }
    }
}

class MessageAdapter : RecyclerView.Adapter<MessageAdapter.VH>() {

    class VH(val b: ItemMessageBinding) : RecyclerView.ViewHolder(b.root)

    private var items: List<Message> = emptyList()
    private val fmt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

    fun submit(list: List<Message>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemMessageBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        holder.b.tvBody.text = m.body
        holder.b.tvTime.text = fmt.format(Date(m.createdAt))
    }
}
