# GroupCast – Android app (Kotlin)

Admin creates groups from the phone's contact list and posts messages; users can only read them.

## Build the .apk (about 2 minutes)
1. Install Android Studio (Hedgehog or newer), then File > Open > select this `GroupCast` folder.
2. Let Gradle sync (needs internet once).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK path: `app/build/outputs/apk/debug/app-debug.apk`  <- submit this file.
   (Command line alternative once the wrapper exists: `./gradlew assembleDebug`)

## How to demo
- Admin login: username `admin`, password `admin123` (select "Admin login").
- Admin taps + > allows contacts access > names the group > ticks contacts > Create group.
- Open a group > type a message > Send. Long-press a group to delete it. Menu > View members.
- Log out. Choose "User login" > "Create an account" using a phone number that is in the group
  (match ignores formatting and country code) > log in. The user sees only their groups and
  a read-only message list; there is no composer.

## Design
- Roles: separate Admin / User login. Admin is seeded; users self-register with name + phone.
- Membership: a user belongs to a group when their registered phone matches a contact the admin picked.
- Storage: local SQLite (SQLiteOpenHelper); passwords stored as salted SHA-256.
- Enforcement: only admin sessions can open CreateGroupActivity; MessagesActivity hides the composer
  and ignores send for users, and users can only open groups they are members of.
- Screens: Login, Register, GroupList, CreateGroup, Messages.

## Limitation
Data is stored on the device, so admin and users share data only on the same phone/emulator.
To deliver messages across different phones, swap `data/Db.kt` for a backend (e.g. Firebase
Auth + Firestore) – the screens and roles stay the same.
